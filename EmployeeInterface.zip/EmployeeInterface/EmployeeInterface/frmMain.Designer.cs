﻿namespace EmployeeInterface
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn1 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn2 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn3 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.GridViewTextBoxColumn gridViewTextBoxColumn4 = new Telerik.WinControls.UI.GridViewTextBoxColumn();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.rgvEmployees = new Telerik.WinControls.UI.RadGridView();
            ((System.ComponentModel.ISupportInitialize)(this.rgvEmployees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgvEmployees.MasterTemplate)).BeginInit();
            this.SuspendLayout();
            // 
            // rgvEmployees
            // 
            this.rgvEmployees.BackColor = System.Drawing.SystemColors.Control;
            this.rgvEmployees.CloseEditorWhenValidationFails = true;
            this.rgvEmployees.Cursor = System.Windows.Forms.Cursors.Default;
            this.rgvEmployees.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rgvEmployees.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.rgvEmployees.ForeColor = System.Drawing.SystemColors.ControlText;
            this.rgvEmployees.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rgvEmployees.Location = new System.Drawing.Point(0, 0);
            // 
            // 
            // 
            gridViewTextBoxColumn1.EnableExpressionEditor = false;
            gridViewTextBoxColumn1.FieldName = "LastName";
            gridViewTextBoxColumn1.HeaderText = "Last Name";
            gridViewTextBoxColumn1.Name = "colLastName";
            gridViewTextBoxColumn1.Width = 180;
            gridViewTextBoxColumn2.EnableExpressionEditor = false;
            gridViewTextBoxColumn2.FieldName = "FirstName";
            gridViewTextBoxColumn2.HeaderText = "First Name";
            gridViewTextBoxColumn2.Name = "colFirstName";
            gridViewTextBoxColumn2.Width = 180;
            gridViewTextBoxColumn3.EnableExpressionEditor = false;
            gridViewTextBoxColumn3.FieldName = "JobTitle";
            gridViewTextBoxColumn3.HeaderText = "Job Title";
            gridViewTextBoxColumn3.Name = "colJobTitle";
            gridViewTextBoxColumn3.Width = 180;
            gridViewTextBoxColumn4.FieldName = "ID";
            gridViewTextBoxColumn4.HeaderText = "ID";
            gridViewTextBoxColumn4.IsVisible = false;
            gridViewTextBoxColumn4.Name = "colID";
            gridViewTextBoxColumn4.Width = 20;
            this.rgvEmployees.MasterTemplate.Columns.AddRange(new Telerik.WinControls.UI.GridViewDataColumn[] {
            gridViewTextBoxColumn1,
            gridViewTextBoxColumn2,
            gridViewTextBoxColumn3,
            gridViewTextBoxColumn4});
            this.rgvEmployees.MasterTemplate.EnableAlternatingRowColor = true;
            this.rgvEmployees.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.rgvEmployees.Name = "rgvEmployees";
            this.rgvEmployees.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rgvEmployees.Size = new System.Drawing.Size(584, 412);
            this.rgvEmployees.StandardTab = true;
            this.rgvEmployees.TabIndex = 0;
            this.rgvEmployees.UserAddedRow += new Telerik.WinControls.UI.GridViewRowEventHandler(this.rgvEmployees_UserAddedRow);
            this.rgvEmployees.UserDeletingRow += new Telerik.WinControls.UI.GridViewRowCancelEventHandler(this.rgvEmployees_UserDeletingRow);
            this.rgvEmployees.CellValueChanged += new Telerik.WinControls.UI.GridViewCellEventHandler(this.rgvEmployees_CellValueChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 412);
            this.Controls.Add(this.rgvEmployees);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Interface";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.rgvEmployees.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgvEmployees)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadGridView rgvEmployees;
    }
}

