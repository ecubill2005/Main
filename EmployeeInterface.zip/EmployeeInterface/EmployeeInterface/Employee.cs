﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeeInterface
{
    class Employee
    {

        public void New(long intID, string strLastName, string strFirstName, string strJobTitle)
        {
            ID = intID;
            LastName = strLastName;
            FirstName = strFirstName;
            JobTitle = strJobTitle;
        }
        public long ID { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string JobTitle { get; set; }

        public override string ToString()
        {            
            return "First Name: " + FirstName + "\r\nLast Name: " + LastName + "\r\nJob Title:" + JobTitle;
        }
    }

   
}
