﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using Telerik.WinControls.UI;


namespace EmployeeInterface
{
    public partial class frmMain : Form
    {
        SQLiteConnection conn = new SQLiteConnection();
        public frmMain()
        {
            InitializeComponent();
        }

        #region "Events"
        private void FrmMain_Load(object sender, EventArgs e)
        {
            
            this.rgvEmployees.AllowAddNewRow = true;
            try
            {
                conn = new SQLiteConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SQLiteDB"].ToString());
                conn.Open();
                BindGrid();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }   
            finally
            {
                
            }        

        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }
        private void rgvEmployees_UserAddedRow(object sender, Telerik.WinControls.UI.GridViewRowEventArgs e)
        {
            try
            {
                if (!ValidateFields(e.Row))
                {
                    MessageBox.Show("All Fields Are Required");
                    BindGrid();
                    return;
                }
                Employee emp;
                emp = new Employee();
                emp.LastName = e.Row.Cells["colLastName"].Value.ToString();
                emp.FirstName = e.Row.Cells["colFirstName"].Value.ToString();
                emp.JobTitle = e.Row.Cells["colJobTitle"].Value.ToString();
                InsertRecord(emp);
                MessageBox.Show("Employee Added\r\n" + emp.ToString() +  "\r\n");
                BindGrid();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }
        private void rgvEmployees_CellValueChanged(object sender, Telerik.WinControls.UI.GridViewCellEventArgs e)
        {
            try
            {
                if (e.Row.Cells["colID"].Value == null)
            {
                //This is not an edit, but is a new row
                return;
            }
                if (!ValidateFields(e.Row))
                {
                    MessageBox.Show("All Fields Are Required");
                    BindGrid();
                    return;
                }
                Employee emp;
            emp = new Employee();
            emp.ID = Convert.ToInt32(e.Row.Cells["colID"].Value.ToString());
            emp.LastName = e.Row.Cells["colLastName"].Value.ToString();
            emp.FirstName = e.Row.Cells["colFirstName"].Value.ToString();
            emp.JobTitle = e.Row.Cells["colJobTitle"].Value.ToString();
            UpdateRecord(emp);           
            MessageBox.Show("Employee Updated\r\n" + emp.ToString());
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }
        private void rgvEmployees_UserDeletingRow(object sender, GridViewRowCancelEventArgs e)
        {
            Employee emp;
            try
            {
                emp = new Employee();
                emp.ID = Convert.ToInt32(e.Rows[0].Cells["colID"].Value.ToString());
                emp.LastName = e.Rows[0].Cells["colLastName"].Value.ToString();
                emp.FirstName = e.Rows[0].Cells["colFirstName"].Value.ToString();
                emp.JobTitle = e.Rows[0].Cells["colJobTitle"].Value.ToString();
                DeleteRecord(emp);
                MessageBox.Show("Employee Deleted\r\n" + emp.ToString());

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }
               
        #endregion

        #region "Helpers"
        private void BindGrid()
        {
            SQLiteCommand com;
            System.Data.DataTable dt = new System.Data.DataTable();
            SQLiteDataAdapter da;
            rgvEmployees.DataSource = null;
            try
            {
                com = new SQLiteCommand();
                com.Connection = conn;
                com.CommandText = "Select * from Employee Order by LastName, FirstName, JobTitle";
                da = new SQLiteDataAdapter(com);
                da.Fill(dt);
                rgvEmployees.DataSource = dt;

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }
        private void InsertRecord(Employee emp)
        {
            SQLiteCommand com;
            try
            {
                com = new SQLiteCommand();
                com.Connection = conn;
                com.CommandText = "Insert Into Employee (LastName, FirstName, JobTitle) values ($LastName,$FirstName,$JobTitle)";
                com.Parameters.AddWithValue("$LastName", emp.LastName);
                com.Parameters.AddWithValue("$FirstName", emp.FirstName);
                com.Parameters.AddWithValue("$JobTitle", emp.JobTitle);
                com.ExecuteNonQuery();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }

        private void UpdateRecord(Employee emp)
        {
            SQLiteCommand com;
            try
            {
                com = new SQLiteCommand();
                com.Connection = conn;
                com.CommandText = "Update Employee set LastName = $LastName,FirstName = $FirstName,JobTitle = $JobTitle Where ID = $ID";
                com.Parameters.AddWithValue("$ID", emp.ID);
                com.Parameters.AddWithValue("$LastName", emp.LastName);
                com.Parameters.AddWithValue("$FirstName", emp.FirstName);
                com.Parameters.AddWithValue("$JobTitle", emp.JobTitle);
                com.ExecuteNonQuery();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }

        private void DeleteRecord(Employee emp)
        {
            SQLiteCommand com;
            try
            {
                com = new SQLiteCommand();
                com.Connection = conn;
                com.CommandText = "Delete from Employee Where ID = $ID";
                com.Parameters.AddWithValue("$ID", emp.ID);
                com.ExecuteNonQuery();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
        }

        private Boolean ValidateFields(Telerik.WinControls.UI.GridViewRowInfo gri)
        {
            try
            {
                foreach (Telerik.WinControls.UI.GridViewCellInfo gci in gri.Cells)
                {
                    if (gci.ColumnInfo.Name != "colID" && gci.Value.ToString() == string.Empty)
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error In " + System.Reflection.MethodBase.GetCurrentMethod().Name + ex.Message + ex.StackTrace);
            }
            return true;
        }



        #endregion


    }
}
